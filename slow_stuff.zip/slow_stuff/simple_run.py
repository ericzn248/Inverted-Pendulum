import comms
import jtracking as t
import time
import tkinter as tk
import math
import cv2
import keyboard
import RL

time.sleep(3) #Wait five seconds to ensure that its set up

lastTime = time.time()

try:
    print("setup complete")
    comms.resetCart()
    RL.testBoundariesAndReset()
    comms.resetCart()

    #we ready
    
    exit()

except KeyboardInterrupt:
    comms.stop()