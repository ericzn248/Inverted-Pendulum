import serial
import serial.tools.list_ports
from time import sleep
import struct
import math
import keyboard
import jtracking as t

t.setup()

COMMS_INFO = [None, None, True] #xloc, angle, status

def boundaryCheck(xavg):
    #checks if the x-position of the cart is out of bounds. Stop it if true.
    global stopped
    if xavg < 25 or xavg> 75:
        stop()
        resetCart(xavg)

def resetCart(cartLoc):
    print("re-centering cart")
    middle = 50
    if(cartLoc==-1):
        print("system fail")
        return
    while(abs(cartLoc[0]-middle)>4):
        if cartLoc[0] < middle: 
            moveRight()
        elif cartLoc[0]>middle: 
            moveLeft()
        cartLoc = t.getPoint(t.red)
    print("done")
    COMMS_INFO[2] = True

def runCV(): 
    #get all relevant locations with CV
    cartLoc = t.getPoint(t.red)
    COMMS_INFO[1] = cartLoc
    #check if we are out of bounds
    boundaryCheck(cartLoc)

DRY_RUN = True
if DRY_RUN:
    #doest need the physical system
    def moveRight():
        sleep(0.5)

    def moveLeft():
        sleep(0.5)

    def agentMove(command): #USE THIS WITH CAUTION
        sleep(0.5)
        
    def stop():
        sleep(0.5)

    def getAngle():
        sleep(0.5)
        return 0, 0
else:
    ports = sorted([port.name for port in serial.tools.list_ports.comports()])
    print(ports)
    port = None
    for p in ports:
        # windows users beware: you might need to hardcode this?!?!
        if "usbserial" in p or "usbmodem" in p or "COM" in p:
            port = p
    if port is None:
        print("No port found")
        quit()
    print(port)
    ser = serial.Serial(port, 115200, timeout=5)


    """
    command:
    b"a" -> communicate that script is ready
    b"p" -> poll current position/time, 
            arduino will send back current position as float (use struct.unpack('f', ...)[0])
            time will be 4 byte float in little endian
    b"s[speed: 1 byte][direction: 1 byte]" -> set speed, then direction as bool (0 for backward, anything else for forward) eg b"s\xff\x01"
    """
    try:
        while not ser.in_waiting:
            sleep(0.01)
        ser.write(b"a")
        ser.read(ser.in_waiting)
        print("initialized")
        ser.write(b"p")
        sleep(0.1)
        if ser.in_waiting:
            print(f"waiting: {ser.in_waiting}")
            angle = struct.unpack("f", ser.read(4))[0]
            time = int.from_bytes(ser.read(4), byteorder="little")
            ser.write(b"p")
            print("current position (radians from start):", angle)
            print("time (ms):", time)
    
        def moveRight():
            ser.write(b"s\xff\x01")
            sleep(0.5)
            ser.write(b"s\x00\x00")

        def moveLeft():
            ser.write(b"s\xff\x00")
            sleep(0.5)
            ser.write(b"s\x00\x00")

        def agentMove(command): #USE THIS WITH CAUTION
            ser.write(command)

        def stop():
            ser.write(b"s\x00\x00")

        def getAngle():
            ser.write(b"p")
            sleep(0.01)
            if ser.in_waiting:
                # print(f"waiting: {ser.in_waiting}")
                angle = struct.unpack("f", ser.read(4))[0]
                time = int.from_bytes(ser.read(4), byteorder="little")
                # print("current position (radians from start):", angle % (math.pi * 2))
                # print("time (ms):", time)
            return angle, time

        if __name__ == "__main__":
            while True:
                if keyboard.is_pressed("left arrow"):
                    ser.write(b"s\xff\x00")

                elif keyboard.is_pressed("right arrow"):
                    ser.write(b"s\xff\x01") 
                
                else:
                    ser.write(b"s\x00\x00")

    # DO NOT CHANGE

    except KeyboardInterrupt:
        # ser.write(b"000f\n")
        ser.write(b"s\x00\x00")
        ser.close()